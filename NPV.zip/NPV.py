#Notes:
"""1. A sample input and output is defined from Line 56 - 69 to explain how the program works. Delete it/Comment out after understanding and before starting to use this program"""
"""2. Fields required to be filled by user are marked with '##'. Wherever the user sees this sign, the section needs to be completed"""
"""3. Reach out at - caapoorvaggarwal1@gmail.com for any suggestions and help"""

#Imports
import pandas as pd
import datetime as dt

#Defining loan class (including NPV and IRR methods)
class Loan:
    """Creates instances of different loans"""
    
    def __init__ (self, ID, drawn, actual, int, n_period = 72, tol_band = 0.04, cycle = True):
        """Assigning attributes"""
        self.ID = ID
        self.drawn = drawn
        self.actual = actual
        self.int = int
        self.n_period = n_period
        self.tol_band = tol_band
        self.cycle = cycle
    
    def NPV(self, df, int_rate):
        installment = df['Installment']
        PV = 0
        counter = 0
        dis_factor = 1 + int_rate
        if self.cycle == True:
            while counter < self.n_period:
                denom = 1 / (dis_factor ** (counter + 1))
                PV += installment[counter] * denom
                counter += 1
        else:
            while counter < self.n_period:
                denom = 1 / (dis_factor ** (counter))
                PV += installment[counter] * denom
                counter += 1
        NPV = PV - self.actual
        NPV_formatted = float(f"{NPV:.2f}")
        return NPV_formatted
        
    def IRR(self, df):
        int_actual = self.int
        tolerance = self.tol_band
        upper_rate = int_actual + tolerance
        lower_rate = int_actual - tolerance
        at_upper = self.NPV(df, upper_rate)
        at_lower = self.NPV(df, lower_rate)
        diff = upper_rate - lower_rate
        if at_lower != at_upper:
            IRR = lower_rate + ((at_lower / (at_lower - at_upper)) * diff)
        else:
            IRR = float('inf')
        IRR_formatted = f"{IRR * 100:.2f}" + "%"
        return IRR_formatted

#Sample Code to explain how to use this code>>>>>>
"""Create a new loan using 'Loan class' as given below"""
loan1 = Loan(123, 20000, 20000, 0.10, 10, 0.04, True)

"""Create a separate excel file and input period and installment in the specified format as given below"""
loan1_df = pd.read_excel('EMI.xlsx')

"""Calculate NPV using the loan (period and installment) df and loan interest as parameters"""
print(loan1.NPV(loan1_df, loan1.int))

"""Calculate IRR using the loan (period and installment) df as parameters"""
print(loan1.IRR(loan1_df))
# Note: Delete above sample before using this program

##Inputs
"""Create loan instances here"""

"""Create loan df here"""


##Output
"""Run the function you want here"""


#Final Output
print("Report run on " + str(dt.date.today()) + " at " + f"{dt.datetime.now():%H-%M}")