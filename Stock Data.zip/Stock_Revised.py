# Imports
import datetime as dt
import time
import pandas as pd
from bsedata.bse import BSE
from concurrent.futures import ThreadPoolExecutor
import xlwings as xw

# Reading the scrip codes
df = pd.read_excel("Combined.xlsx") #! This is an important input. Don't change this file directly.
scrip_codes = df['Security Code'].tolist()
revised_scrip = [str(code) for code in scrip_codes]

# Setting up BSE object
bse = BSE()

# Defining functions
def get_data(scrip_code, retries = 3, delay = 1):
    for attempt in range (retries):
        try:
            data = bse.getQuote(scrip_code)
            if data and 'companyName' in data:
                return [scrip_code, data['companyName'], data['currentValue'], data['change']]
            else:
                raise ValueError("Invalid response from API")
        except Exception as e:
            print(f"Error fetching {scrip_code}, Attempt {attempt + 1}: {e}")
            time.sleep(delay)
            return [scrip_code, "N/A", "N/A", "N/A"]

def fetch_stock_data_concurrent(scrips):
    with ThreadPoolExecutor(max_workers=10) as executor:
        results = list(executor.map(get_data,scrips))
    return results

def update_stock_data():
    batch_size = 50 #? Should I change this based on the time the code is taking?
    nested_result = []
    for i in range(0,len(revised_scrip),batch_size):
        batch = revised_scrip[i:i + batch_size]
        print(f"Batch {i//batch_size + 1}")
        # Performing the function
        result = fetch_stock_data_concurrent(batch)
        time.sleep(1)
        nested_result.extend(result)
        time.sleep(1)

    # Converting to DataFrame
    columns = ["Security Code", "Company Name", "Current Value", "Change"]
    df_result = pd.DataFrame(nested_result, columns = columns)

    # Converting to excel using xlwings
    """Open the Existing file"""
    wb = xw.book("Stock_Data.xlsm")
    """Adjust sheet name if needed"""
    ws = wb.sheets["Stock Data Raw"]
    """Column Headers"""
    ws.range("A1").value = columns
    ws.range("A2").value = df_result.values
    wb.save()
    print("Stock data updated successfully in Stock_Data.xlsm")